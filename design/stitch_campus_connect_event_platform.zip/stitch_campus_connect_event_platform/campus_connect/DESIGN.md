---
name: Campus Connect
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#464555'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#712ae2'
  on-secondary: '#ffffff'
  secondary-container: '#8a4cfc'
  on-secondary-container: '#fffbff'
  tertiary: '#005522'
  on-tertiary: '#ffffff'
  tertiary-container: '#00702f'
  on-tertiary-container: '#78f591'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#eaddff'
  secondary-fixed-dim: '#d2bbff'
  on-secondary-fixed: '#25005a'
  on-secondary-fixed-variant: '#5a00c6'
  tertiary-fixed: '#7ffc97'
  tertiary-fixed-dim: '#62df7d'
  on-tertiary-fixed: '#002109'
  on-tertiary-fixed-variant: '#005320'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  title-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.005em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-xs:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system drives a premium, focused event intelligence and discovery platform for university innovators, builders, and researchers. It bridges the structural rigor of high-performance product software (Linear) with the dynamic curation and social presence of premier event platforms (Eventbrite).

### Visual Aesthetic & Philosophy
- **Precision Minimalism**: High density without visual fatigue. Whitespace acts as structural containment rather than passive emptiness.
- **Academic Modernism**: Combines collegiate authority with dynamic venture-tech energy through deep indigo depths, luminous violet highlights, and sharp slate typography.
- **Quiet Clarity**: Interfaces de-emphasize heavy ornamental dividers in favor of crisp surface stacking, clean perimeter boundaries, and fine hairline borders.

## Colors

The palette establishes an unmistakable, vibrant anchor with deep indigo and violet while grounding all workflows in accessible slate and neutral-cool slates.

### Palette Construction
- **Primary Indigo (`#4F46E5`)**: Key interactive triggers, active tab states, and prominent callouts.
- **Secondary Violet (`#7C3AED`)**: Specialized indicators, hackathon/keynote event features, and accent gradients.
- **Background (`#F8FAFC`)**: Base canvas tone; soft, cool-tinted grey preventing screen glare.
- **Surface (`#FFFFFF`)**: Pure white cards, sheets, and elevated overlays.
- **Text & Neutral (`#0F172A`)**: High-contrast text base with intermediate shades (`#475569` for secondary copy, `#94A3B8` for subtle metadata).
- **Functional Semantics**:
  - Success: `#16A34A` (RSVP confirmed, ticket secured)
  - Warning: `#F59E0B` (Seats limited, fast-filling workshops)
  - Danger: `#EF4444` (Event sold out, cancelled session)

## Typography

Inter serves as the primary typographic backbone across headlines, copy, and UI metadata. 

### Typographic Principles
- **Tracking & Proportion**: Tighten tracking on larger display headlines (`-0.02em` to `-0.03em`) to project intentional, modern technical precision.
- **Hierarchy Separation**: High weights (`600`, `700`) are reserved for structural headings and badges. Long-form event briefs and agenda schedules rely on clean, neutral `400` weights paired with open line height for immediate scannability.
- **Tabular Precision**: Timestamps, seat availability counters, and calendar dates should enforce tabular numerals (`tnum`) to maintain vertical rhythm across tabular lists.

## Layout & Spacing

The layout model uses a responsive 12-column grid system paired with strict 8px layout rhythm for components and vertical stacking.

### Breakpoints & Structure
- **Mobile (< 768px)**: 4 columns, `margin-mobile` (16px), and `gutter-mobile` (16px). Single-column event cards, collapsible search panels, and fixed bottom actions.
- **Tablet (768px - 1024px)**: 8 columns, 24px margins, 20px gutters. Two-column grid configurations for directory cards.
- **Desktop (> 1024px)**: 12 columns, max-width 1280px, 32px margins, 24px gutters. Master-detail navigation models, split calendar views, and persistent side navigation.

## Elevation & Depth

Visual hierarchy combines low-opacity ambient shadows with soft border containment. Depth is functional and strictly controlled to maintain an uncluttered aesthetic.

### Elevation Levels
- **Level 0 (Flat Surface)**: Clean `#F8FAFC` base without shadows or borders.
- **Level 1 (Card & Content Container)**: Pure white background `#FFFFFF`, bordered by 1px solid `rgba(15, 23, 42, 0.08)`, elevated with an ambient shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.03)`.
- **Level 2 (Hover & Active States)**: Transition state for hoverable cards: `0 8px 20px -4px rgba(15, 23, 42, 0.08), 0 4px 6px -2px rgba(15, 23, 42, 0.03)`, border tone deepens to `rgba(79, 70, 229, 0.25)`.
- **Level 3 (Modals, Overlays & Popovers)**: RSVP drawers, filter popovers: `0 20px 25px -5px rgba(15, 23, 42, 0.1), 0 8px 10px -6px rgba(15, 23, 42, 0.05)`, backed by a `backdrop-blur(8px)` with `rgba(15, 23, 42, 0.35)` overlay.

## Shapes

The design uses a 14px to 16px radius curve system for cards and containers, complemented by pill contours for metadata chips and action pills.

### Geometry Rules
- **Panels & Cards**: 14px to 16px (`rounded-lg` to `rounded-xl`) corner radius creates an approachable, modern feel without appearing cartoonish.
- **Inputs & Interactive Form Elements**: 8px to 10px border radius for tight visual anchoring.
- **Pill Tags & Category Badges**: Full radius (`9999px`) for contextual filters, campus badges, and status pills.

## Components

### Buttons
- **Primary**: Solid `#4F46E5` fill, `#FFFFFF` text, `font-weight: 600`, 8px radius. Subtle inset highlight (`inset 0 1px 0 rgba(255,255,255,0.15)`). Hover elevates with `#4338CA`.
- **Secondary**: Surface `#FFFFFF`, border `1px solid rgba(15, 23, 42, 0.12)`, text `#0F172A`. Hover shifts background to `#F1F5F9`.
- **Ghost/Tertiary**: Transparent fill, `#475569` text, background becomes `#F1F5F9` on hover.

### Filter Pills & Badges
- **Pill Filters**: 32px height, fully rounded (`rounded-full`), padded `space-md` horizontally. Inactive state: `#FFFFFF` surface with `1px solid rgba(15, 23, 42, 0.1)`. Active state: `#0F172A` background with `#FFFFFF` text.
- **Status Badges**: Ultra-compact (20px height), `label-xs` typography, subtle tinted backgrounds:
  - Open/Free: Background `#DCFCE7`, text `#166534`.
  - Closing Soon: Background `#FEF3C7`, text `#92400E`.
  - Keynote/Special: Background `#EDE9FE`, text `#6D28D9`.

### Event Cards
- Base: `#FFFFFF` surface, 16px corner radius, 1px border `rgba(15, 23, 42, 0.08)`, padded with `space-lg`.
- Top: Date stamp pill (e.g., "OCT 24") paired with category label.
- Center: `headline-md` title, followed by university departmental source and 2-line truncated description.
- Bottom: Host avatars, attendee count, and quick RSVP action button.

### Form Inputs & Search Fields
- Height 42px (Search hero bar: 48px), 8px corner radius.
- Background `#FFFFFF`, 1px border `rgba(15, 23, 42, 0.14)`.
- Focused: Border transitions to `#4F46E5` with `0 0 0 3px rgba(79, 70, 229, 0.15)` ring.
- Placeholder text: `#94A3B8`.

### Checkboxes & Segmented Controls
- Checkboxes: 18x18px square with 4px corner radius. Inactive: `1px solid #CBD5E1`. Active: `#4F46E5` fill with white checkmark.
- Segmented View Toggle (List vs. Map vs. Calendar): Enclosed track with `#F1F5F9` background, 8px radius, sliding white active segment pill with Level 1 shadow.